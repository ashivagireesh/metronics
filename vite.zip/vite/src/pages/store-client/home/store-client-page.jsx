import { Container } from '@/components/common/container';
import { StoreClientContent } from '.';

export function StoreClientPage() {
  return (
    <Container>
      <StoreClientContent />
    </Container>
  );
}
