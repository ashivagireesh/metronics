import { Container } from '@/components/common/container';
import { Demo2Content } from '.';

export function Demo2Page() {
  return (
    <Container>
      <Demo2Content />
    </Container>
  );
}
