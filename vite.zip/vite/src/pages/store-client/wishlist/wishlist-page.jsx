import { Container } from '@/components/common/container';
import { WishlistContent } from '.';

export function WishlistPage() {
  return (
    <Container>
      <WishlistContent />
    </Container>
  );
}
