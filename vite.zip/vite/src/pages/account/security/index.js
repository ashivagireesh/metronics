export * from './allowed-ip-addresses/account-basic-page';
export * from './backup-and-recovery/account-basic-page';
export * from './current-sessions/account-basic-page';
export * from './device-management/account-basic-page';
export * from './get-started/account-basic-page';
export * from './overview/account-basic-page';
export * from './privacy-settings/account-basic-page';
export * from './security-log/account-basic-page';
