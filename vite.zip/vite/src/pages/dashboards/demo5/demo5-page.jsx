import { Container } from '@/components/common/container';
import { Demo5Content } from '.';

export function Demo5Page() {
  return (
    <Container>
      <Demo5Content />
    </Container>
  );
}
