import { SearchResults } from '../search-results-grid';

export function SearchResultsListContent() {
  return <SearchResults mode="list" />;
}
