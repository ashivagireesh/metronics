import { OrderReceipt } from './components/order-receipt';

export function OrderReceiptContent() {
  return <OrderReceipt />;
}
