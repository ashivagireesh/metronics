import { Container } from '@/components/common/container';
import { Demo3Content } from '.';

export function Demo3Page() {
  return (
    <Container>
      <Demo3Content />
    </Container>
  );
}
