import { Container } from '@/components/common/container';
import { Demo4Content } from '.';

export function Demo4Page() {
  return (
    <Container>
      <Demo4Content />
    </Container>
  );
}
