import { Demo1LightSidebarContent } from '@/pages/dashboards/demo1';
import { Container } from '@/components/common/container';

export function AuthGetStartedPage() {
  return (
    <Container>
      <Demo1LightSidebarContent />
    </Container>
  );
}
