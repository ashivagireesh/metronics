import { Container } from '@/components/common/container';
import { OrderReceiptContent } from '.';

export function OrderReceiptPage() {
  return (
    <Container>
      <OrderReceiptContent />
    </Container>
  );
}
